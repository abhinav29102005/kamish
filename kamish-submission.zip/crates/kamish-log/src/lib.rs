//! Segmented Append-Only Log with Dense Monotonic Offsets, fsync Flush Durability, and Checksum Verification.
//!
//! Complies with `project.md`:
//! - §3.1.1: Produce Path with Policy Enforcement and Acknowledgment (fsync flush durability).
//! - §3.5.2: Record Envelope Layout (magic, epoch, class_id, policy_version, base_offset, payload, checksum).
//! - INV-1: Offsets are dense and monotonic per partition.
//! - INV-2: Acknowledged record is durable on disk before Ack.
//! - INV-4: A fetch never returns records beyond the committed high-water mark.

use crc32fast::Hasher as CrcHasher;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::sync::{Arc, RwLock};
use thiserror::Error;

pub const RECORD_MAGIC_V1: u16 = 0x4859; // "HY"
pub const RECORD_MAGIC_V2: u16 = 0x485A;

/// Persisted with the payload in one checksummed/fsynced record, never in a
/// separate session file that could get ahead of or behind the commit log.
fn default_source_generation() -> u64 {
    1
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecordContext {
    pub producer_id: u64,
    pub producer_epoch: u64,
    pub sequence: u32,
    pub origin_region: String,
    pub request_policy: String,
    /// Snapshot of permitted destinations at admission. Recovery intersects
    /// this list with current policy; it cannot invent new destinations.
    pub replication_targets: Vec<String>,
    #[serde(default = "default_source_generation")]
    pub source_generation: u64,
}

impl RecordContext {
    pub fn new(
        producer_id: u64,
        producer_epoch: u64,
        sequence: u32,
        origin_region: impl Into<String>,
        request_policy: impl Into<String>,
        replication_targets: Vec<String>,
    ) -> Self {
        Self {
            producer_id,
            producer_epoch,
            sequence,
            origin_region: origin_region.into(),
            request_policy: request_policy.into(),
            replication_targets,
            source_generation: 1,
        }
    }

    pub fn with_source_generation(mut self, generation: u64) -> Self {
        self.source_generation = generation;
        self
    }
}

#[derive(Debug, Error)]
pub enum LogError {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Log directory {0:?} is locked by another physical process (W14)")]
    LockedByAnotherProcess(PathBuf),

    #[error("Invalid record magic byte: {0:#x}")]
    InvalidMagic(u16),

    #[error("Checksum mismatch at offset {offset}: computed {computed:#x}, recorded {recorded:#x}")]
    ChecksumMismatch {
        offset: u64,
        computed: u32,
        recorded: u32,
    },

    #[error("Stale epoch write attempt: broker epoch is {current}, append request was {requested}")]
    StaleEpoch { current: u64, requested: u64 },

    #[error("Offset gap detected: expected monotonic offset {expected}, but received {received}")]
    NonMonotonicOffset { expected: u64, received: u64 },

    #[error("Partition log writer is fenced: {0}")]
    WriterFenced(String),
}

/// Abstract storage writer supporting atomic fsync, truncation repair, and length queries.
pub trait StorageWriter: Send + std::io::Write {
    fn sync_all(&mut self) -> std::io::Result<()>;
    fn set_len(&mut self, size: u64) -> std::io::Result<()>;
    fn file_len(&mut self) -> std::io::Result<u64>;
    fn seek_end(&mut self) -> std::io::Result<u64>;
}

impl StorageWriter for std::fs::File {
    fn sync_all(&mut self) -> std::io::Result<()> {
        std::fs::File::sync_all(self)
    }

    fn set_len(&mut self, size: u64) -> std::io::Result<()> {
        std::fs::File::set_len(self, size)
    }

    fn file_len(&mut self) -> std::io::Result<u64> {
        self.metadata().map(|m| m.len())
    }

    fn seek_end(&mut self) -> std::io::Result<u64> {
        use std::io::Seek;
        self.seek(std::io::SeekFrom::End(0))
    }
}

/// Deterministic failure injection points for StorageWriter testing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FaultInjectionPoint {
    LengthWrite,
    BodyWrite,
    Flush,
    Sync,
    TruncationRepair,
    RepairSync,
}

/// Test utility wrapping a `StorageWriter` to simulate deterministic I/O failures.
pub struct FaultInjectingWriter<W: StorageWriter> {
    inner: W,
    fault: Option<FaultInjectionPoint>,
    write_count: usize,
    in_repair: bool,
    partial_bytes: usize,
}

impl<W: StorageWriter> FaultInjectingWriter<W> {
    pub fn new(inner: W, fault: FaultInjectionPoint, partial_bytes: usize) -> Self {
        Self {
            inner,
            fault: Some(fault),
            write_count: 0,
            in_repair: false,
            partial_bytes,
        }
    }

    pub fn inner_mut(&mut self) -> &mut W {
        &mut self.inner
    }

    pub fn into_inner(self) -> W {
        self.inner
    }

    pub fn clear_fault(&mut self) {
        self.fault = None;
        self.in_repair = false;
        self.write_count = 0;
    }
}

impl<W: StorageWriter> std::io::Write for FaultInjectingWriter<W> {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        match self.fault {
            Some(FaultInjectionPoint::LengthWrite) => {
                if self.partial_bytes > 0 {
                    let to_write = self.partial_bytes.min(buf.len());
                    let _ = self.inner.write_all(&buf[..to_write]);
                }
                self.fault = None;
                Err(std::io::Error::other("simulated length-write I/O failure"))
            }
            Some(FaultInjectionPoint::BodyWrite) => {
                if self.write_count == 0 {
                    self.write_count += 1;
                    self.inner.write_all(buf)?;
                    Ok(buf.len())
                } else {
                    if self.partial_bytes > 0 {
                        let to_write = self.partial_bytes.min(buf.len());
                        let _ = self.inner.write_all(&buf[..to_write]);
                    }
                    self.fault = None;
                    Err(std::io::Error::other("simulated body-write I/O failure"))
                }
            }
            Some(FaultInjectionPoint::TruncationRepair) | Some(FaultInjectionPoint::RepairSync) => {
                if self.partial_bytes > 0 {
                    let to_write = self.partial_bytes.min(buf.len());
                    let _ = self.inner.write_all(&buf[..to_write]);
                }
                Err(std::io::Error::other(
                    "simulated initial write failure to trigger repair",
                ))
            }
            _ => self.inner.write(buf),
        }
    }

    fn flush(&mut self) -> std::io::Result<()> {
        if self.fault == Some(FaultInjectionPoint::Flush) {
            self.fault = None;
            return Err(std::io::Error::other("simulated flush I/O failure"));
        }
        self.inner.flush()
    }
}

impl<W: StorageWriter> StorageWriter for FaultInjectingWriter<W> {
    fn sync_all(&mut self) -> std::io::Result<()> {
        if self.in_repair {
            if self.fault == Some(FaultInjectionPoint::RepairSync) {
                self.fault = None;
                return Err(std::io::Error::other("simulated repair sync I/O failure"));
            }
            return self.inner.sync_all();
        }

        if self.fault == Some(FaultInjectionPoint::Sync) {
            self.fault = None;
            return Err(std::io::Error::other("simulated sync_all I/O failure"));
        }

        self.inner.sync_all()
    }

    fn set_len(&mut self, size: u64) -> std::io::Result<()> {
        self.in_repair = true;
        if self.fault == Some(FaultInjectionPoint::TruncationRepair) {
            self.fault = None;
            return Err(std::io::Error::other("simulated truncation repair failure"));
        }
        self.inner.set_len(size)
    }

    fn file_len(&mut self) -> std::io::Result<u64> {
        self.inner.file_len()
    }

    fn seek_end(&mut self) -> std::io::Result<u64> {
        self.inner.seek_end()
    }
}

#[derive(Debug)]
enum AppendStageError {
    LengthWrite(std::io::Error),
    BodyWrite(std::io::Error),
    Flush(std::io::Error),
    Sync(std::io::Error),
}

/// Standard Hydra Stream record envelope (§3.5.2).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct RecordEnvelope {
    pub magic: u16,
    pub epoch: u64,
    pub class_id: String,
    pub policy_version: u64,
    pub base_offset: u64,
    pub payload: Vec<u8>,
    pub checksum: u32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub context: Option<RecordContext>,
}

impl RecordEnvelope {
    pub fn new(
        epoch: u64,
        class_id: impl Into<String>,
        policy_version: u64,
        base_offset: u64,
        payload: Vec<u8>,
    ) -> Self {
        let class_str = class_id.into();
        let checksum =
            Self::compute_checksum(epoch, &class_str, policy_version, base_offset, &payload);
        Self {
            magic: RECORD_MAGIC_V1,
            epoch,
            class_id: class_str,
            policy_version,
            base_offset,
            payload,
            checksum,
            context: None,
        }
    }

    pub fn compute_checksum(
        epoch: u64,
        class_id: &str,
        policy_version: u64,
        base_offset: u64,
        payload: &[u8],
    ) -> u32 {
        let mut hasher = CrcHasher::new();
        hasher.update(&RECORD_MAGIC_V1.to_be_bytes());
        hasher.update(&epoch.to_be_bytes());
        hasher.update(class_id.as_bytes());
        hasher.update(&policy_version.to_be_bytes());
        hasher.update(&base_offset.to_be_bytes());
        hasher.update(payload);
        hasher.finalize()
    }

    pub fn verify_checksum(&self) -> bool {
        self.expected_checksum()
            .is_some_and(|computed| computed == self.checksum)
    }

    pub fn expected_checksum(&self) -> Option<u32> {
        match (self.magic, &self.context) {
            (RECORD_MAGIC_V1, None) => Some(Self::compute_checksum(
                self.epoch,
                &self.class_id,
                self.policy_version,
                self.base_offset,
                &self.payload,
            )),
            (RECORD_MAGIC_V2, Some(context)) => {
                let bytes = serde_json::to_vec(&(
                    self.magic,
                    self.epoch,
                    &self.class_id,
                    self.policy_version,
                    self.base_offset,
                    &self.payload,
                    context,
                ))
                .ok()?;
                Some(crc32fast::hash(&bytes))
            }
            _ => None,
        }
    }
}

/// In-memory and persistent partition log manager enforcing INV-1, INV-2, and INV-4.
#[derive(Clone)]
pub struct PartitionLog {
    inner: Arc<RwLock<PartitionLogInner>>,
    writer_lock: Arc<std::sync::Mutex<Option<Box<dyn StorageWriter>>>>,
}

impl std::fmt::Debug for PartitionLog {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let inner = self.inner.read().unwrap();
        f.debug_struct("PartitionLog")
            .field("dir", &inner.dir)
            .field("current_epoch", &inner.current_epoch)
            .field("next_offset", &inner.next_offset)
            .field("high_watermark", &inner.high_watermark)
            .field("fenced", &inner.fenced_reason.is_some())
            .finish()
    }
}

/// Physical file lock preventing multiple processes from concurrently mutating a partition log (W14).
#[derive(Debug)]
pub struct PartitionLock {
    _file: File,
}

impl PartitionLock {
    pub fn acquire(dir: &Path) -> Result<Self, LogError> {
        let lock_path = dir.join(".lock");
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&lock_path)?;

        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            let fd = file.as_raw_fd();
            let ret = unsafe { libc::flock(fd, libc::LOCK_EX | libc::LOCK_NB) };
            if ret != 0 {
                return Err(LogError::LockedByAnotherProcess(dir.to_path_buf()));
            }
        }

        #[cfg(windows)]
        {
            use std::os::windows::io::AsRawHandle;
            #[link(name = "kernel32")]
            unsafe extern "system" {
                fn LockFileEx(
                    hFile: *mut std::ffi::c_void,
                    dwFlags: u32,
                    dwReserved: u32,
                    nNumberOfBytesToLockLow: u32,
                    nNumberOfBytesToLockHigh: u32,
                    lpOverlapped: *mut std::ffi::c_void,
                ) -> i32;
            }
            const LOCKFILE_FAIL_IMMEDIATELY: u32 = 0x00000001;
            const LOCKFILE_EXCLUSIVE_LOCK: u32 = 0x00000002;

            let handle = file.as_raw_handle();
            let mut overlapped = std::mem::MaybeUninit::<[u8; 32]>::zeroed();
            let ret = unsafe {
                LockFileEx(
                    handle,
                    LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY,
                    0,
                    1,
                    0,
                    overlapped.as_mut_ptr() as *mut std::ffi::c_void,
                )
            };
            if ret == 0 {
                return Err(LogError::LockedByAnotherProcess(dir.to_path_buf()));
            }
        }

        Ok(Self { _file: file })
    }
}

/// Sparse index entry mapping log base offset to on-disk byte offset in segment (W15/W16).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct SparseIndexEntry {
    pub base_offset: u64,
    pub position: u64,
}

/// Result of storage reclamation under topic retention policies.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct RetentionReclaimResult {
    pub reclaimed_records: usize,
    pub reclaimed_bytes: u64,
    pub new_base_offset_floor: u64,
}

struct PartitionLogInner {
    dir: PathBuf,
    current_epoch: u64,
    base_offset_floor: u64,
    next_offset: u64,
    high_watermark: u64,
    records: Vec<RecordEnvelope>,
    fenced_reason: Option<String>,
    _lock: PartitionLock,
    max_segment_bytes: u64,
    index_entries: Vec<SparseIndexEntry>,
}

impl PartitionLog {
    pub fn open<P: AsRef<Path>>(dir: P, initial_epoch: u64) -> Result<Self, LogError> {
        let dir_buf = dir.as_ref().to_path_buf();
        std::fs::create_dir_all(&dir_buf)?;
        let lock = PartitionLock::acquire(&dir_buf)?;

        let log_file = dir_buf.join("partition.data");
        let mut records = Vec::new();
        let mut next_offset = 0;

        if log_file.exists() {
            let mut file = File::open(&log_file)?;
            let mut buf = Vec::new();
            file.read_to_end(&mut buf)?;

            let total_len = buf.len() as u64;
            let mut cursor = std::io::Cursor::new(buf);
            let mut valid_file_len = 0u64;

            loop {
                let start_pos = cursor.position();
                if start_pos == total_len {
                    // Clean end of file reached
                    break;
                }

                match bincode_deserialize_envelope(&mut cursor) {
                    Ok(envelope) => {
                        let computed = envelope
                            .expected_checksum()
                            .ok_or(LogError::InvalidMagic(envelope.magic))?;
                        if computed != envelope.checksum {
                            return Err(LogError::ChecksumMismatch {
                                offset: envelope.base_offset,
                                computed,
                                recorded: envelope.checksum,
                            });
                        }
                        if envelope.base_offset != next_offset {
                            return Err(LogError::NonMonotonicOffset {
                                expected: next_offset,
                                received: envelope.base_offset,
                            });
                        }
                        next_offset += 1;
                        records.push(envelope);
                        valid_file_len = cursor.position();
                    }
                    Err(e) => {
                        // Check if this error is due to an incomplete/torn write at the very tail of the file
                        let current_pos = cursor.position();
                        let is_eof_error = e.kind() == std::io::ErrorKind::UnexpectedEof;

                        if is_eof_error && (current_pos == total_len || start_pos + 4 > total_len) {
                            // Truncate trailing torn write at segment tail back to last verified record
                            drop(file);
                            let trunc_file = OpenOptions::new().write(true).open(&log_file)?;
                            trunc_file.set_len(valid_file_len)?;
                            trunc_file.sync_all()?;
                            break;
                        } else {
                            // Middle-of-segment corruption or corrupt frame: must fail loudly!
                            return Err(LogError::Io(e));
                        }
                    }
                }
            }
        }

        let high_watermark = records.len() as u64;
        let recovered_epoch = records
            .iter()
            .map(|record| record.epoch)
            .max()
            .unwrap_or(initial_epoch);

        // Build sparse index entries for binary search (W15/W16)
        let mut index_entries = Vec::new();
        let idx_file = dir_buf.join("partition.idx");
        if let Ok(content) = std::fs::read(&idx_file)
            && let Ok(entries) = serde_json::from_slice::<Vec<SparseIndexEntry>>(&content)
        {
            index_entries = entries;
        }
        if index_entries.is_empty() {
            for (idx, r) in records.iter().enumerate() {
                if idx.is_multiple_of(10) || idx == records.len() - 1 {
                    index_entries.push(SparseIndexEntry {
                        base_offset: r.base_offset,
                        position: idx as u64,
                    });
                }
            }
        }

        let base_offset_floor = records.first().map(|r| r.base_offset).unwrap_or(0);

        Ok(Self {
            inner: Arc::new(RwLock::new(PartitionLogInner {
                dir: dir_buf,
                current_epoch: initial_epoch.max(recovered_epoch),
                base_offset_floor,
                next_offset,
                high_watermark,
                records,
                fenced_reason: None,
                _lock: lock,
                max_segment_bytes: 10 * 1024 * 1024, // 10MB default segment roll (W15)
                index_entries,
            })),
            writer_lock: Arc::new(std::sync::Mutex::new(None)),
        })
    }

    /// Appends a payload batch, enforcing INV-1 (monotonic dense offsets), epoch fencing (§3.4.2),
    /// and fsync flush durability to underlying disk hardware (§3.1.1, INV-2).
    ///
    /// Decoupled concurrency architecture:
    /// Disk file I/O and hardware `sync_all` are serialized under `writer_lock` without holding
    /// `inner.write()`. This guarantees concurrent readers fetching records are NEVER blocked by
    /// ongoing fsync operations.
    pub fn append(
        &self,
        epoch: u64,
        class_id: impl Into<String>,
        policy_version: u64,
        payload: Vec<u8>,
    ) -> Result<u64, LogError> {
        self.append_with_context(epoch, class_id, policy_version, payload, None)
    }

    pub fn append_envelope(&self, envelope: RecordEnvelope) -> Result<u64, LogError> {
        self.append_with_context(
            envelope.epoch,
            envelope.class_id,
            envelope.policy_version,
            envelope.payload,
            envelope.context,
        )
    }

    pub fn append_with_context(
        &self,
        epoch: u64,
        class_id: impl Into<String>,
        policy_version: u64,
        payload: Vec<u8>,
        context: Option<RecordContext>,
    ) -> Result<u64, LogError> {
        // Fast-path: reject immediately if log writer is fenced
        if let Some(reason) = self.fenced_reason() {
            return Err(LogError::WriterFenced(reason));
        }

        // 1. Serialize writers to guarantee continuous monotonic sequence numbering (INV-1)
        let mut writer_guard = self.writer_lock.lock().unwrap();

        // Double check fence under writer_lock to prevent race conditions
        if let Some(reason) = self.fenced_reason() {
            return Err(LogError::WriterFenced(reason));
        }

        // 2. Validate epoch and reserve next offset under brief write lock
        let (offset, dir) = {
            let mut inner = self.inner.write().unwrap();
            if epoch < inner.current_epoch {
                return Err(LogError::StaleEpoch {
                    current: inner.current_epoch,
                    requested: epoch,
                });
            }
            if epoch > inner.current_epoch {
                inner.current_epoch = epoch;
            }
            (inner.next_offset, inner.dir.clone())
        };

        // 3. Construct and serialize envelope BEFORE modifying the file
        let mut envelope = RecordEnvelope::new(epoch, class_id, policy_version, offset, payload);
        if context.is_some() {
            envelope.magic = RECORD_MAGIC_V2;
            envelope.context = context;
            envelope.checksum = envelope.expected_checksum().expect("valid v2 envelope");
        }

        let serialized = serde_json::to_vec(&envelope)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        let len_bytes = (serialized.len() as u32).to_be_bytes();

        // 4. Open or reuse storage writer
        if writer_guard.is_none() {
            let log_path = dir.join("partition.data");
            let mut file = OpenOptions::new()
                .create(true)
                .truncate(false)
                .read(true)
                .write(true)
                .open(&log_path)?;
            use std::io::Seek;
            file.seek(std::io::SeekFrom::End(0))?;
            #[cfg(unix)]
            File::open(&dir)?.sync_all()?;
            *writer_guard = Some(Box::new(file));
        }

        let writer = writer_guard.as_mut().unwrap();

        // Ensure writer is positioned at the end of the file
        writer.seek_end()?;

        // 5. Capture the original on-disk file length before writing
        let original_len = writer.file_len()?;

        // 6. Explicitly write length-prefix, body, flush, and sync_all.
        // We do NOT use bare `?` on operations that can mutate disk state without rollback.
        let write_result: Result<(), AppendStageError> = (|| {
            writer
                .write_all(&len_bytes)
                .map_err(AppendStageError::LengthWrite)?;
            writer
                .write_all(&serialized)
                .map_err(AppendStageError::BodyWrite)?;
            writer.flush().map_err(AppendStageError::Flush)?;
            writer.sync_all().map_err(AppendStageError::Sync)?;
            Ok(())
        })();

        if let Err(stage_err) = write_result {
            return self.handle_append_failure(writer_guard, original_len, stage_err);
        }

        // 7. Once crash-durable on disk, publish record to in-memory committed log and advance HWM (INV-4)
        {
            let mut inner = self.inner.write().unwrap();
            inner.records.push(envelope);
            inner.next_offset += 1;
            inner.high_watermark += 1;

            // Sparse index update (W15/W16)
            let rec_idx = inner.records.len() - 1;
            if rec_idx.is_multiple_of(10) {
                inner.index_entries.push(SparseIndexEntry {
                    base_offset: offset,
                    position: rec_idx as u64,
                });
            }
        }

        Ok(offset)
    }

    fn handle_append_failure(
        &self,
        mut writer_guard: std::sync::MutexGuard<'_, Option<Box<dyn StorageWriter>>>,
        original_len: u64,
        stage_err: AppendStageError,
    ) -> Result<u64, LogError> {
        let (io_err, is_sync_failure, stage_name) = match stage_err {
            AppendStageError::LengthWrite(e) => (e, false, "length write"),
            AppendStageError::BodyWrite(e) => (e, false, "body write"),
            AppendStageError::Flush(e) => (e, false, "flush"),
            AppendStageError::Sync(e) => (e, true, "sync_all"),
        };

        let writer = writer_guard.as_mut().unwrap();

        // 1. Attempt rollback by truncating back to original length
        let truncate_res = writer.set_len(original_len);
        let repair_sync_res = if truncate_res.is_ok() {
            let _ = writer.seek_end();
            writer.sync_all()
        } else {
            Err(std::io::Error::other("truncation set_len failed"))
        };

        // 2. Unrecoverable truncation failure -> fence writer
        if let Err(ref set_len_err) = truncate_res {
            let reason = format!(
                "Append failed during {stage_name} ({io_err}); truncation repair to {original_len} failed: {set_len_err}"
            );
            self.fence(&reason);
            *writer_guard = None;
            return Err(LogError::WriterFenced(reason));
        }

        // 3. Unrecoverable truncation sync failure -> fence writer
        if let Err(ref sync_err) = repair_sync_res {
            let reason = format!(
                "Append failed during {stage_name} ({io_err}); truncation repair sync failed: {sync_err}"
            );
            self.fence(&reason);
            *writer_guard = None;
            return Err(LogError::WriterFenced(reason));
        }

        // 4. Uncertainty on sync_all durability -> fence writer
        if is_sync_failure {
            let reason =
                format!("Append sync_all failed with uncertain storage persistence: {io_err}");
            self.fence(&reason);
            *writer_guard = None;
            return Err(LogError::Io(io_err));
        }

        // 5. Successful rollback and healthy writer -> keep reusable
        let _ = writer.seek_end();
        Err(LogError::Io(io_err))
    }

    /// Sets the maximum segment file size before rolling to a new segment (W15/W16).
    pub fn set_max_segment_bytes(&self, max_bytes: u64) {
        self.inner.write().unwrap().max_segment_bytes = max_bytes;
    }

    pub fn max_segment_bytes(&self) -> u64 {
        self.inner.read().unwrap().max_segment_bytes
    }

    /// Returns the sparse index entries for fast binary search (W15/W16).
    pub fn sparse_index(&self) -> Vec<SparseIndexEntry> {
        self.inner.read().unwrap().index_entries.clone()
    }

    /// Binary searches the sparse index to locate the nearest starting position for an offset (W15/W16).
    pub fn lookup_offset_position(&self, target_offset: u64) -> Option<u64> {
        let inner = self.inner.read().unwrap();
        if inner.index_entries.is_empty() {
            return None;
        }
        let entries = &inner.index_entries;
        match entries.binary_search_by_key(&target_offset, |e| e.base_offset) {
            Ok(idx) => Some(entries[idx].position),
            Err(0) => Some(entries[0].position),
            Err(idx) => Some(entries[idx - 1].position),
        }
    }
    /// Fetches records starting at `start_offset`, capped strictly by the High-Water Mark (INV-4).
    pub fn read(&self, start_offset: u64, max_records: usize) -> Vec<RecordEnvelope> {
        let inner = self.inner.read().unwrap();
        let effective_start = start_offset.max(inner.base_offset_floor);
        if effective_start >= inner.high_watermark || inner.records.is_empty() {
            return Vec::new();
        }

        let rel_start = (effective_start - inner.base_offset_floor) as usize;
        if rel_start >= inner.records.len() {
            return Vec::new();
        }

        let count = std::cmp::min(max_records, inner.records.len() - rel_start);
        inner.records[rel_start..rel_start + count].to_vec()
    }

    /// Sequential consumer reads between `[start_offset, end_offset)`.
    pub fn read_range(&self, start_offset: u64, end_offset: u64) -> Vec<RecordEnvelope> {
        let inner = self.inner.read().unwrap();
        let effective_start = start_offset.max(inner.base_offset_floor);
        if effective_start >= inner.high_watermark
            || effective_start >= end_offset
            || inner.records.is_empty()
        {
            return Vec::new();
        }

        let rel_start = (effective_start - inner.base_offset_floor) as usize;
        if rel_start >= inner.records.len() {
            return Vec::new();
        }

        let effective_end = std::cmp::min(end_offset, inner.high_watermark);
        if effective_end <= effective_start {
            return Vec::new();
        }
        let rel_end = (effective_end - inner.base_offset_floor) as usize;
        inner.records[rel_start..rel_end.min(inner.records.len())].to_vec()
    }

    pub fn next_offset(&self) -> u64 {
        self.inner.read().unwrap().next_offset
    }

    pub fn base_offset_floor(&self) -> u64 {
        self.inner.read().unwrap().base_offset_floor
    }

    pub fn current_epoch(&self) -> u64 {
        self.inner.read().unwrap().current_epoch
    }

    pub fn high_watermark(&self) -> u64 {
        self.inner.read().unwrap().high_watermark
    }

    pub fn is_fenced(&self) -> bool {
        self.inner.read().unwrap().fenced_reason.is_some()
    }

    pub fn fenced_reason(&self) -> Option<String> {
        self.inner.read().unwrap().fenced_reason.clone()
    }

    pub fn fence(&self, reason: impl Into<String>) {
        let mut inner = self.inner.write().unwrap();
        if inner.fenced_reason.is_none() {
            inner.fenced_reason = Some(reason.into());
        }
    }

    pub fn set_storage_writer(&self, writer: Box<dyn StorageWriter>) {
        let mut guard = self.writer_lock.lock().unwrap();
        *guard = Some(writer);
    }

    /// Returns a copy of records starting from `from_offset` up to `next_offset` (including uncommitted).
    /// Used to safely prepare divergent suffixes for quarantine before truncating (§3.1.4, W20).
    pub fn read_suffix(&self, from_offset: u64) -> Vec<RecordEnvelope> {
        let inner = self.inner.read().unwrap();
        let effective_start = from_offset.max(inner.base_offset_floor);
        if effective_start >= inner.next_offset || inner.records.is_empty() {
            return Vec::new();
        }
        let rel_start = (effective_start - inner.base_offset_floor) as usize;
        if rel_start < inner.records.len() {
            inner.records[rel_start..].to_vec()
        } else {
            Vec::new()
        }
    }

    /// Safely reclaims historical records prior to `reclaim_before_offset` if they have been
    /// fully committed and acknowledged by all active consumer groups and replication watermarks.
    /// Uses crash-safe atomic file replacement with temporary file sync_all (§3.1, W15/W16).
    pub fn reclaim_prefix_before_offset(
        &self,
        reclaim_before_offset: u64,
    ) -> Result<RetentionReclaimResult, LogError> {
        let mut writer_guard = self.writer_lock.lock().unwrap();
        let mut inner = self.inner.write().unwrap();

        if let Some(ref reason) = inner.fenced_reason {
            return Err(LogError::WriterFenced(reason.clone()));
        }

        if reclaim_before_offset <= inner.base_offset_floor || inner.records.is_empty() {
            return Ok(RetentionReclaimResult {
                reclaimed_records: 0,
                reclaimed_bytes: 0,
                new_base_offset_floor: inner.base_offset_floor,
            });
        }

        // Preserve active segment tail: retain at least the latest record to preserve segment metadata
        let max_reclaimable = inner.high_watermark.saturating_sub(1);
        let effective_target = reclaim_before_offset.min(max_reclaimable);
        let split_idx = inner
            .records
            .partition_point(|r| r.base_offset < effective_target);

        if split_idx == 0 {
            return Ok(RetentionReclaimResult {
                reclaimed_records: 0,
                reclaimed_bytes: 0,
                new_base_offset_floor: inner.base_offset_floor,
            });
        }

        let retained_records = inner.records[split_idx..].to_vec();
        let reclaimed_records_count = split_idx;
        let mut reclaimed_bytes = 0u64;
        for r in &inner.records[..split_idx] {
            reclaimed_bytes += r.payload.len() as u64 + 64;
        }

        // Write replacement partition.data using tempfile and sync_all
        let mut tmp_file = tempfile::NamedTempFile::new_in(&inner.dir)?;
        for rec in &retained_records {
            let serialized = serde_json::to_vec(rec)
                .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
            let len_bytes = (serialized.len() as u32).to_be_bytes();
            tmp_file.write_all(&len_bytes)?;
            tmp_file.write_all(&serialized)?;
        }
        tmp_file.flush()?;
        tmp_file.as_file().sync_all()?;

        // Recompute sparse index for retained records
        let mut new_index = Vec::new();
        for (i, rec) in retained_records.iter().enumerate() {
            if i % 10 == 0 || i == retained_records.len() - 1 {
                new_index.push(SparseIndexEntry {
                    base_offset: rec.base_offset,
                    position: i as u64,
                });
            }
        }

        let idx_serialized = serde_json::to_vec(&new_index)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        let mut tmp_idx = tempfile::NamedTempFile::new_in(&inner.dir)?;
        tmp_idx.write_all(&idx_serialized)?;
        tmp_idx.flush()?;
        tmp_idx.as_file().sync_all()?;

        // Drop current writer handle before rename
        *writer_guard = None;

        let log_path = inner.dir.join("partition.data");
        let idx_path = inner.dir.join("partition.idx");

        tmp_file.persist(&log_path).map_err(|e| {
            let reason = format!("Retention atomic data replacement failed: {e}");
            inner.fenced_reason = Some(reason.clone());
            LogError::Io(e.error)
        })?;

        tmp_idx.persist(&idx_path).map_err(|e| {
            let reason = format!("Retention atomic index replacement failed: {e}");
            inner.fenced_reason = Some(reason.clone());
            LogError::Io(e.error)
        })?;

        #[cfg(unix)]
        {
            let dir_file = File::open(&inner.dir)?;
            dir_file.sync_all()?;
        }

        let new_floor = retained_records
            .first()
            .map(|r| r.base_offset)
            .unwrap_or(inner.next_offset);
        inner.base_offset_floor = new_floor;
        inner.records = retained_records;
        inner.index_entries = new_index;

        Ok(RetentionReclaimResult {
            reclaimed_records: reclaimed_records_count,
            reclaimed_bytes,
            new_base_offset_floor: new_floor,
        })
    }

    /// Truncates the log to `new_next_offset`, removing all records with `base_offset >= new_next_offset`.
    /// Returns the removed records (superseded suffix) for quarantine routing (§3.1.4, W20).
    ///
    /// Failure-Safe Durability Protocol (FN-02.1):
    /// 1. Verifies writer is not fenced before starting.
    /// 2. Prepares retained prefix and superseded suffix without mutating original in-memory state.
    /// 3. Writes replacement partition.data to a temporary file in the same directory.
    /// 4. Flushes and sync_all() to ensure data durability on disk before installation.
    /// 5. Writes replacement partition.idx to a temporary file and syncs it.
    /// 6. Closes active file writer handle before atomic replacement.
    /// 7. Atomically installs replacement files using platform-safe replacement semantics.
    /// 8. On Unix, synchronizes the containing directory.
    /// 9. ONLY AFTER replacement succeeds on disk does in-memory state transition to truncated prefix.
    /// 10. Any failure before installation leaves original in-memory log intact.
    /// 11. Any ambiguous replacement outcome fences the writer fail-closed.
    pub fn truncate_to_offset(
        &self,
        new_next_offset: u64,
    ) -> Result<Vec<RecordEnvelope>, LogError> {
        let mut writer_guard = self.writer_lock.lock().unwrap();
        let mut inner = self.inner.write().unwrap();

        // 1. Writer fencing check
        if let Some(ref reason) = inner.fenced_reason {
            return Err(LogError::WriterFenced(reason.clone()));
        }

        // 2. Early return if nothing to truncate
        if new_next_offset >= inner.next_offset {
            return Ok(Vec::new());
        }

        let split_idx = new_next_offset as usize;
        if split_idx > inner.records.len() {
            return Ok(Vec::new());
        }

        // 3. Prepare retained and superseded collections WITHOUT mutating in-memory log
        let retained_records = inner.records[..split_idx].to_vec();
        let superseded_records = inner.records[split_idx..].to_vec();
        let retained_index: Vec<SparseIndexEntry> = inner
            .index_entries
            .iter()
            .filter(|e| e.base_offset < new_next_offset)
            .copied()
            .collect();

        // 4. Write replacement partition.data to a temporary file
        let mut tmp_file = tempfile::NamedTempFile::new_in(&inner.dir)?;
        for rec in &retained_records {
            let serialized = serde_json::to_vec(rec)
                .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
            let len_bytes = (serialized.len() as u32).to_be_bytes();
            tmp_file.write_all(&len_bytes)?;
            tmp_file.write_all(&serialized)?;
        }
        tmp_file.flush()?;
        tmp_file.as_file().sync_all()?;

        // 5. Write replacement partition.idx to a temporary file
        let idx_serialized = serde_json::to_vec(&retained_index)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        let mut idx_tmp = tempfile::NamedTempFile::new_in(&inner.dir)?;
        idx_tmp.write_all(&idx_serialized)?;
        idx_tmp.flush()?;
        idx_tmp.as_file().sync_all()?;

        // 6. Close existing writer handle before replacing files on disk
        *writer_guard = None;

        // 7. Atomically replace partition.data and partition.idx
        let log_path = inner.dir.join("partition.data");
        let idx_path = inner.dir.join("partition.idx");

        if let Err(e) = tmp_file.persist(&log_path) {
            let is_intact = std::fs::metadata(&log_path).is_ok();
            if !is_intact {
                let msg = format!("truncation_replacement_ambiguous: {}", e.error);
                inner.fenced_reason = Some(msg.clone());
                return Err(LogError::WriterFenced(msg));
            }
            return Err(LogError::Io(e.error));
        }

        // Persist index (non-fatal if index fails, will rebuild on open)
        let _ = idx_tmp.persist(&idx_path);

        // 8. Synchronize directory on platforms that support it
        #[cfg(unix)]
        {
            if let Ok(dir_file) = std::fs::File::open(&inner.dir) {
                let _ = dir_file.sync_all();
            }
        }

        // 9. ONLY AFTER installation succeeds, transition in-memory state
        inner.records = retained_records;
        inner.next_offset = new_next_offset;
        inner.high_watermark = new_next_offset;
        inner.index_entries = retained_index;

        Ok(superseded_records)
    }
}

pub fn bincode_deserialize_envelope(
    cursor: &mut std::io::Cursor<Vec<u8>>,
) -> Result<RecordEnvelope, std::io::Error> {
    let mut len_bytes = [0u8; 4];
    cursor.read_exact(&mut len_bytes)?;
    let len = u32::from_be_bytes(len_bytes) as usize;

    let mut buf = vec![0u8; len];
    cursor.read_exact(&mut buf)?;
    serde_json::from_slice(&buf)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))
}

/// Decodes length-prefixed RecordEnvelopes from raw storage bytes without requiring exclusive partition locks.
pub fn decode_envelopes_from_bytes(bytes: &[u8]) -> Vec<RecordEnvelope> {
    let mut cursor = std::io::Cursor::new(bytes.to_vec());
    let mut records = Vec::new();
    while let Ok(envelope) = bincode_deserialize_envelope(&mut cursor) {
        records.push(envelope);
    }
    records
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_two_processes_opening_same_log_directory_reject() {
        let temp_dir = tempfile::tempdir().unwrap();
        let log1 = PartitionLog::open(temp_dir.path(), 1).unwrap();

        // Attempting to open the same partition log concurrently must fail with LockedByAnotherProcess
        let open_res = PartitionLog::open(temp_dir.path(), 1);
        assert!(matches!(open_res, Err(LogError::LockedByAnotherProcess(_))));

        // Dropping the original log releases the lock
        drop(log1);
        assert!(PartitionLog::open(temp_dir.path(), 1).is_ok());
    }

    #[test]
    fn test_monotonic_offset_and_crc_verification() {
        let temp_dir = tempfile::tempdir().unwrap();
        let log = PartitionLog::open(temp_dir.path(), 1).unwrap();

        let o0 = log
            .append(1, "EU-class", 1, b"first payload".to_vec())
            .unwrap();
        assert_eq!(o0, 0);

        let o1 = log
            .append(1, "EU-class", 1, b"second payload".to_vec())
            .unwrap();
        assert_eq!(o1, 1);

        assert_eq!(log.next_offset(), 2);
        assert_eq!(log.high_watermark(), 2);

        // Fetch respects HWM (INV-4)
        let records = log.read(0, 10);
        assert_eq!(records.len(), 2);
        assert_eq!(records[0].base_offset, 0);
        assert_eq!(records[1].base_offset, 1);
        assert!(records[0].verify_checksum());
        assert!(records[1].verify_checksum());

        // Drop log before reopening to release partition lock (W14)
        drop(log);

        // Reopening preserves monotonic state
        let reopened = PartitionLog::open(temp_dir.path(), 1).unwrap();
        assert_eq!(reopened.next_offset(), 2);
    }

    #[test]
    fn test_stale_epoch_rejection() {
        let temp_dir = tempfile::tempdir().unwrap();
        let log = PartitionLog::open(temp_dir.path(), 5).unwrap();

        let err = log
            .append(4, "EU-class", 1, b"stale write".to_vec())
            .unwrap_err();
        assert!(matches!(
            err,
            LogError::StaleEpoch {
                current: 5,
                requested: 4
            }
        ));
    }

    #[test]
    fn test_fsync_flush_durability_and_sequential_reads() {
        let temp_dir = tempfile::tempdir().unwrap();
        let path = temp_dir.path().to_path_buf();

        // 1. Write 200 records with fsync durability
        {
            let log = PartitionLog::open(&path, 1).unwrap();
            for i in 0..200 {
                let payload = format!("durable-event-payload-{:04}", i).into_bytes();
                let offset = log.append(1, "sovereign-class", 1, payload).unwrap();
                assert_eq!(offset, i as u64);
            }
            assert_eq!(log.high_watermark(), 200);
            // PartitionLog dropped here, simulating broker shutdown/process termination
        }

        // 2. Restart recovery: reopen partition log from raw disk files
        let recovered = PartitionLog::open(&path, 1).unwrap();
        assert_eq!(recovered.high_watermark(), 200);
        assert_eq!(recovered.next_offset(), 200);

        // 3. Verify sequential consumer offset reads in chunks of 50
        let mut consumed = 0;
        let mut cur_offset = 0;
        while cur_offset < 200 {
            let chunk = recovered.read(cur_offset, 50);
            assert_eq!(chunk.len(), 50);
            for record in chunk {
                assert_eq!(record.base_offset, cur_offset);
                assert!(record.verify_checksum());
                let expected_payload =
                    format!("durable-event-payload-{:04}", cur_offset).into_bytes();
                assert_eq!(record.payload, expected_payload);
                cur_offset += 1;
                consumed += 1;
            }
        }
        assert_eq!(consumed, 200);

        // 4. Test read_range slice
        let slice = recovered.read_range(10, 25);
        assert_eq!(slice.len(), 15);
        assert_eq!(slice[0].base_offset, 10);
        assert_eq!(slice[14].base_offset, 24);
    }

    #[test]
    fn test_torn_write_tail_truncation_recovery() {
        let temp_dir = tempfile::tempdir().unwrap();
        let path = temp_dir.path().to_path_buf();
        let data_path = path.join("partition.data");

        // 1. Write 3 valid records
        {
            let log = PartitionLog::open(&path, 1).unwrap();
            log.append(1, "sovereign", 1, b"record-0".to_vec()).unwrap();
            log.append(1, "sovereign", 1, b"record-1".to_vec()).unwrap();
            log.append(1, "sovereign", 1, b"record-2".to_vec()).unwrap();
            assert_eq!(log.high_watermark(), 3);
        }

        let valid_len = std::fs::metadata(&data_path).unwrap().len();

        // 2. Simulate dirty crash / torn write by appending 15 bytes of truncated corrupt data
        {
            let mut file = OpenOptions::new().append(true).open(&data_path).unwrap();
            // Incomplete header bytes representing a torn write
            file.write_all(&[0x00, 0x00, 0x01, 0xFF, 0xDE, 0xAD, 0xBE, 0xEF])
                .unwrap();
            file.flush().unwrap();
        }
        let corrupt_len = std::fs::metadata(&data_path).unwrap().len();
        assert!(corrupt_len > valid_len);

        // 3. Re-open log: it should detect the torn write at the tail, truncate back to valid_len,
        // and cleanly recover the 3 valid records.
        let recovered = PartitionLog::open(&path, 1).unwrap();
        assert_eq!(recovered.high_watermark(), 3);
        assert_eq!(recovered.next_offset(), 3);

        let records = recovered.read(0, 10);
        assert_eq!(records.len(), 3);
        assert_eq!(records[0].payload, b"record-0");
        assert_eq!(records[1].payload, b"record-1");
        assert_eq!(records[2].payload, b"record-2");

        let current_len = std::fs::metadata(&data_path).unwrap().len();
        assert_eq!(
            current_len, valid_len,
            "Tail truncation should restore exact valid length"
        );

        // 4. Verify that new appends succeed cleanly at offset 3
        let o3 = recovered
            .append(1, "sovereign", 1, b"record-3".to_vec())
            .unwrap();
        assert_eq!(o3, 3);
        assert_eq!(recovered.high_watermark(), 4);

        // Drop recovered before reopening to release partition lock (W14)
        drop(recovered);

        // 5. Subsequent reopen finds all 4 valid records intact
        let reopened = PartitionLog::open(&path, 1).unwrap();
        assert_eq!(reopened.high_watermark(), 4);
        assert_eq!(reopened.read(0, 10).len(), 4);
    }
}

#[derive(Debug, Error)]
pub enum SessionError {
    #[error("Producer sequence exhausted; begin a new producer epoch")]
    SequenceExhausted,
    #[error("Out of order sequence: expected {expected}, received {received}")]
    OutOfOrderSequence { expected: u32, received: u32 },

    #[error("Producer epoch stale: expected >= {current}, received {received}")]
    StaleProducerEpoch { current: u64, received: u64 },
}

/// Producer session tracking to guarantee deduplication and sequence ordering (§3.4.2).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProducerSessionState {
    pub producer_id: u64,
    pub producer_epoch: u64,
    pub last_seq: u32,
    pub last_offset: u64,
}

/// In-memory thread-safe session manager per partition.
#[derive(Clone, Default)]
pub struct SessionManager {
    sessions: Arc<RwLock<HashMap<u64, ProducerSessionState>>>,
}

impl SessionManager {
    pub fn new() -> Self {
        Self::default()
    }

    /// Evaluates sequence ordering:
    /// - If seq == last_seq: returns Ok(Some(last_offset)) as an idempotent duplicate retry (INV-6).
    /// - If seq == last_seq + 1 (or first seq 0): returns Ok(None) to proceed with append.
    /// - Otherwise: returns Err(OutOfOrderSequence).
    pub fn check_sequence(
        &self,
        producer_id: u64,
        producer_epoch: u64,
        seq: u32,
    ) -> Result<Option<u64>, SessionError> {
        let sessions = self.sessions.read().unwrap();
        if let Some(state) = sessions.get(&producer_id) {
            if producer_epoch < state.producer_epoch {
                return Err(SessionError::StaleProducerEpoch {
                    current: state.producer_epoch,
                    received: producer_epoch,
                });
            }

            if producer_epoch > state.producer_epoch {
                return if seq == 0 {
                    Ok(None)
                } else {
                    Err(SessionError::OutOfOrderSequence {
                        expected: 0,
                        received: seq,
                    })
                };
            }

            if seq == state.last_seq {
                // Duplicate retry: return cached offset without appending (INV-6)
                return Ok(Some(state.last_offset));
            }

            let expected = state
                .last_seq
                .checked_add(1)
                .ok_or(SessionError::SequenceExhausted)?;
            if seq != expected {
                return Err(SessionError::OutOfOrderSequence {
                    expected,
                    received: seq,
                });
            }
        } else if seq != 0 {
            // First message from a session must start at sequence 0
            return Err(SessionError::OutOfOrderSequence {
                expected: 0,
                received: seq,
            });
        }

        Ok(None)
    }

    /// Updates session state after successful fsync and append.
    pub fn update(&self, producer_id: u64, producer_epoch: u64, seq: u32, offset: u64) {
        let mut sessions = self.sessions.write().unwrap();
        sessions.insert(
            producer_id,
            ProducerSessionState {
                producer_id,
                producer_epoch,
                last_seq: seq,
                last_offset: offset,
            },
        );
    }
}

#[cfg(test)]
mod session_tests {
    use super::*;

    #[test]
    fn test_idempotent_session_deduplication() {
        let sm = SessionManager::new();

        // 1. Initial message seq 0
        let res = sm.check_sequence(101, 1, 0).unwrap();
        assert_eq!(res, None);
        sm.update(101, 1, 0, 42);

        // 2. Duplicate retry seq 0 -> returns cached offset 42 (INV-6)
        let dup = sm.check_sequence(101, 1, 0).unwrap();
        assert_eq!(dup, Some(42));

        // 3. Next message seq 1 -> proceeds
        let res1 = sm.check_sequence(101, 1, 1).unwrap();
        assert_eq!(res1, None);
        sm.update(101, 1, 1, 43);

        // 4. Out-of-order seq 3 (skipped seq 2) -> rejected
        let err = sm.check_sequence(101, 1, 3).unwrap_err();
        assert!(matches!(
            err,
            SessionError::OutOfOrderSequence {
                expected: 2,
                received: 3
            }
        ));
    }
}
